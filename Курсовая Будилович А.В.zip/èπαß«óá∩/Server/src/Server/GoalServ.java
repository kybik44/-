package Server;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class GoalServ {
    public static String addGoal(String title, String description) {
        String aMessage = "";
        try {
            BufferedReader buffer = new BufferedReader(new InputStreamReader(new FileInputStream("./enter/goal.txt")));
            String t;
            while ((t = buffer.readLine()) != null) {
                buffer.readLine();
                if (t.equals(title)) {
                    aMessage = "Есть цель с таким заголовком!";
                    break;
                }
            }
            buffer.close();

            if (aMessage.equals("")) {
                aMessage = "Цель успешно добавлена!";

                FileWriter fileWriter = new FileWriter("./enter/goal.txt", true);
                System.out.println(title + " " + description);
                fileWriter.write(title + "\n");
                fileWriter.write(description + "\n");
                fileWriter.flush();
                fileWriter.close();
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return aMessage;
    }

    public static String deleteGoal(String title) {
        String aMessage = "";
        String des;
        try {
            BufferedReader bufferedReader;
            FileWriter fileWriter;
            bufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream("./enter/goal.txt")));
            String t;
            while ((t = bufferedReader.readLine()) != null) {
                bufferedReader.readLine();
                if (t.equals(title)) {
                    aMessage = "Цель успешно удалена!";
                }
            }

            if (!aMessage.equals("")) {
                bufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream("./enter/goal.txt")));
                fileWriter = new FileWriter("./enter/buffer.txt", true);

                while ((t = bufferedReader.readLine()) != null) {
                    des = bufferedReader.readLine();
                    if (!t.equals(title)) {
                        fileWriter.write(t + "\n");
                        fileWriter.write(des + "\n");
                    }
                }
                fileWriter.close();

                bufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream("./enter/buffer.txt")));
                fileWriter = new FileWriter("./enter/goal.txt");
                while ((t = bufferedReader.readLine()) != null) {
                    des = bufferedReader.readLine();
                    fileWriter.write(t + "\n");
                    fileWriter.write(des + "\n");
                    fileWriter.flush();
                }
                fileWriter = new FileWriter("./enter/buffer.txt");
                fileWriter.write("");
                fileWriter.close();
            } else {
                aMessage = "Нет цели с таким заголовком!";
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return aMessage;
    }

    public static List<String> showGoals() {
        ArrayList<String> res = new ArrayList<>();
        try {
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream("./enter/goal.txt")));
            String t;
            String des;
            while ((t = bufferedReader.readLine()) != null) {
                des = bufferedReader.readLine();
                res.add(t + ";" + des + ";");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        res.add(";;");
        return res;
    }
}


 {
