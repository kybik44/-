package Server;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.List;

import static Server.BServ.*;
import static Server.ExpertServ.*;
import static Server.GoalServ.*;
import static Server.CommonServ.*;

public class mainServer {
    private static Socket clientSocket;
    private static ServerSocket server;
    private static BufferedReader in;
    private static BufferedWriter out;

    public static void main(String[] args) throws IOException {
        try {
            server = new ServerSocket(4044);
            System.out.println("Сервер запущен!");
            clientSocket = server.accept();
            in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            out = new BufferedWriter(new OutputStreamWriter(clientSocket.getOutputStream()));

            while (true) {
                String message = in.readLine();
                String command[];
                command = message.split(";");
                switch (command[0]) {
                    case "authorization":
                        out.write(Enter(command[1], command[2], command[3]) + System.lineSeparator());
                        out.flush();
                        break;
                    case "addB":
                        out.write(addB(command[1], command[2]) + System.lineSeparator());
                        out.flush();
                        break;
                    case "showB":
                        List<String> list = showB();
                        for (String i : list) {
                            out.write(i + System.lineSeparator());
                            out.flush();
                        }
                        break;
                    case "deleteB":
                        out.write(deleteB(command[1]) + System.lineSeparator());
                        out.flush();
                        break;
                    case "changeB":
                        out.write(changeB(command[1], command[2]) + System.lineSeparator());
                        out.flush();
                        break;
                    case "addExpert":
                        out.write(addExpert(command[1], command[2]) + System.lineSeparator());
                        out.flush();
                        break;
                    case "showExperts":
                        list = showExperts();
                        for (String i : list) {
                            out.write(i + System.lineSeparator());
                            out.flush();
                        }
                        break;
                    case "findExpert":
                        out.write(findExpert(command[1]) + System.lineSeparator());
                        out.flush();
                        break;
                    case "deleteExpert":
                        out.write(deleteExpert(command[1]) + System.lineSeparator());
                        out.flush();
                        break;
                    case "changeExpert":
                        out.write(changeExpert(command[1], command[2]) + System.lineSeparator());
                        out.flush();
                        break;
                    case "addGoal":
                        out.write(addGoal(command[1], command[2]) + System.lineSeparator());
                        out.flush();
                        break;
                    case "deleteGoal":
                        out.write(deleteGoal(command[1]) + System.lineSeparator());
                        out.flush();
                        break;
                    case "showGoals":
                        list = showGoals();
                        for (String i : list) {
                            out.write(i + System.lineSeparator());
                            out.flush();
                        }
                        break;
                    case "NewExpMark":
                        list = showGoals();
                        for (String i : list) {
                            out.write(i + System.lineSeparator());
                            out.flush();
                        }
                        out.write(newExpertMark(command[1], in.readLine()) + System.lineSeparator());
                        out.flush();
                        break;
                    case "showRes":
                        out.write(expertsNumber() + System.lineSeparator());
                        out.flush();
                        list = showGoals();
                        out.write((list.size() - 1) + System.lineSeparator());
                        out.flush();
                        for (String i : list) {
                            out.write(i + System.lineSeparator());
                            out.flush();
                        }
                        list = showExperts();
                        for (String i : list) {
                            out.write(i + System.lineSeparator());
                            out.flush();
                        }
                        break;
                    case "exit":
                        clientSocket.close();
                        return;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            server.close();
            clientSocket.close();
        }
    }
}
