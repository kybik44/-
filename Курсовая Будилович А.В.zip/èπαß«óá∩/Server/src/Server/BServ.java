package Server;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class BServ {
    public static String addB(String title, String description) {
        String aMessage = "";
        try {
            BufferedReader buffer = new BufferedReader(new InputStreamReader(new FileInputStream("./enter/bake.txt")));
            String tit;
            while ((tit = buffer.readLine()) != null) {
                buffer.readLine();
                if (tit.equals(title)) {
                    aMessage = "Есть услуга с таким названием!";
                    break;
                }
            }
            if (aMessage.equals("")) {
                aMessage = " успешно добавлена!";
                FileWriter fileWriter = new FileWriter("./enter/bake.txt", true);
                fileWriter.write(title + "\n");
                fileWriter.write(description + "\n");
                fileWriter.close();
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return aMessage;
    }
    public static List<String> showB() {
        ArrayList<String> res = new ArrayList<>();
        try {
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream("./enter/bake.txt")));
            String tit;
            String descr;
            while ((tit = bufferedReader.readLine()) != null) {
                descr = bufferedReader.readLine();
                res.add(tit + ";" + descr + ";");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        res.add(";;");
        return res;
    }
    public static String deleteB(String title) {
        String aMessage = "";
        try {
            BufferedReader bufferedReader;
            FileWriter fileWriter;
            bufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream("./enter/bake.txt")));
            String tit;
            String desr;
            while ((tit = bufferedReader.readLine()) != null) {
                bufferedReader.readLine();
                if (tit.equals(title)) {
                    aMessage = " успешно удалено!";
                }
            }

            if (!aMessage.equals("")) {
                bufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream("./enter/bake.txt")));
                fileWriter = new FileWriter("./enter/buffer.txt", true);

                while ((tit = bufferedReader.readLine()) != null) {
                    desr = bufferedReader.readLine();
                    if (!tit.equals(title)) {
                        fileWriter.write(tit + "\n");
                        fileWriter.write(desr + "\n");
                    }
                }
                fileWriter.close();

                bufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream("./enter/buffer.txt")));
                fileWriter = new FileWriter("./enter/bake.txt");
                while ((tit = bufferedReader.readLine()) != null) {
                    desr = bufferedReader.readLine();
                    fileWriter.write(tit + "\n");
                    fileWriter.write(desr + "\n");
                    fileWriter.flush();
                }

                fileWriter = new FileWriter("./enter/buffer.txt");
                fileWriter.write("");
                fileWriter.close();
            } else {
                aMessage = "Нет услуги с таким названием!";
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return aMessage;
    }
    public static String changeB(String title, String deskr) {
        String aMessage = "";
        try {
            BufferedReader bufferedReader;
            FileWriter fileWriter;
            bufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream("./enter/bake.txt")));
            String t;
            String d;
            while ((t = bufferedReader.readLine()) != null) {
                d = bufferedReader.readLine();
                if (t.equals(title)) {
                    aMessage = "Информация о услуге успешно отредактирована!";
                }
            }

            if (!aMessage.equals("")) {
                bufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream("./enter/bake.txt")));
                fileWriter = new FileWriter("./enter/buffer.txt", true);

                while ((t = bufferedReader.readLine()) != null) {
                    d = bufferedReader.readLine();
                    fileWriter.write(t + "\n");
                    if (!t.equals(title)) {
                        fileWriter.write(d + "\n");
                    } else {
                        fileWriter.write(deskr + "\n");
                    }
                }
                fileWriter.close();

                bufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream("./enter/buffer.txt")));
                fileWriter = new FileWriter("./enter/bake.txt");
                while ((t = bufferedReader.readLine()) != null) {
                    d = bufferedReader.readLine();
                    fileWriter.write(t + "\n");
                    fileWriter.write(d + "\n");
                    fileWriter.flush();
                }
                fileWriter = new FileWriter("./enter/buffer.txt");
                fileWriter.write("");
                fileWriter.close();
            } else {
                aMessage = "Нет услуги с таким названием!";
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return aMessage;
    }

}
