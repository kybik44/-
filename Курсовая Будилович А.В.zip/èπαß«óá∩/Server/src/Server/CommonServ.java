package Server;

import java.io.*;

public class CommonServ {

    public static String Enter(String role, String login, String password) {
        try {
            BufferedReader buffer = new BufferedReader(new InputStreamReader(new FileInputStream("./enter/" + role + ".txt")));
            String log;
            String pass;
            while ((log = buffer.readLine()) != null) {
                pass = buffer.readLine();
                if (role.equals("expert")) {
                    buffer.readLine();}
                if ((pass.equals(password)) && (log.equals(login))) {
                    System.out.print(login+password);
                    return "Yes";
                }
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "No";
    }

    public static String newExpertMark(String login, String marks) {
        String aMessage = "Оценки успешно занесены!";
        try {
            BufferedReader bufferedReader;
            marks = marks.trim();
            FileWriter fileWriter;
            String log;
            String pass;
            String m;
                bufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream("./enter/expert.txt")));
                fileWriter = new FileWriter("./enter/buffer.txt", true);

                while ((log = bufferedReader.readLine()) != null) {
                    pass = bufferedReader.readLine();
                    m = bufferedReader.readLine();
                    fileWriter.write(log + "\n");
                    fileWriter.write(pass + "\n");
                    if (!log.equals(login)) {
                        fileWriter.write(m + "\n");
                    } else {
                        fileWriter.write(marks + "\n");
                    }
                }
                fileWriter.close();

                bufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream("./enter/buffer.txt")));
                fileWriter = new FileWriter("./enter/expert.txt");
                while ((log = bufferedReader.readLine()) != null) {
                    pass = bufferedReader.readLine();
                    m = bufferedReader.readLine();

                    fileWriter.write(log + "\n");
                    fileWriter.write(pass + "\n");
                    fileWriter.write(m + "\n");
                    fileWriter.flush();
                }
                fileWriter = new FileWriter("./enter/buffer.txt");
                fileWriter.write("");
                fileWriter.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return aMessage;
    }


}
