package Server;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class ExpertServ {
    public static String addExpert(String login, String password) {
        String aMessage = "";
        try {
            BufferedReader buffer = new BufferedReader(new InputStreamReader(new FileInputStream("./enter/expert.txt")));
            String log;
            while ((log = buffer.readLine()) != null) {
                buffer.readLine();
                buffer.readLine();
                if (log.equals(login)) {
                    aMessage = "Есть эксперт с таким логином!";
                    break;
                }
            }
            if (aMessage.equals("")) {
                aMessage = "Эксперт успешно добавлен!";
                FileWriter fileWriter = new FileWriter("./enter/expert.txt", true);
                System.out.println(login + " " + password);
                fileWriter.write(login + "\n");
                fileWriter.write(password + "\n");
                fileWriter.write("0 0 0" + "\n");
                fileWriter.close();
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return aMessage;
    }
    public static List<String> showExperts() {
        ArrayList<String> mes = new ArrayList<>();
        try {
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream("./enter/expert.txt")));
            String log;
            String pass;
            String marks;

            while ((log = bufferedReader.readLine()) != null) {
                pass = bufferedReader.readLine();
                marks = bufferedReader.readLine();
                mes.add(log + ";" + pass + ";" + marks + ";");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        mes.add(";;");
        return mes;
    }
    public static String findExpert(String login) {
        StringBuilder mes = new StringBuilder();
        try {
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream("./enter/expert.txt")));
            String log;
            String pass;
            String marks;

            while ((log = bufferedReader.readLine()) != null) {
                pass = bufferedReader.readLine();
                marks = bufferedReader.readLine();
                if (log.equals(login)) {
                    mes.append(log + ";" + pass + ";" + marks + ";");
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return mes.toString();
    }
    public static String deleteExpert(String login) {
        String aMessage = "";
        try {
            BufferedReader bufferedReader;
            FileWriter fileWriter;
            bufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream("./enter/expert.txt")));
            String log;
            String pass;
            String marks;
            while ((log = bufferedReader.readLine()) != null) {
                bufferedReader.readLine();
                bufferedReader.readLine();
                if (log.equals(login)) {
                    aMessage = "Эксперт успешно удален!";
                }
            }

            if (!aMessage.equals("")) {
                bufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream("./enter/expert.txt")));
                fileWriter = new FileWriter("./enter/buffer.txt", true);

                while ((log = bufferedReader.readLine()) != null) {
                    pass = bufferedReader.readLine();
                    marks = bufferedReader.readLine();
                    if (!log.equals(login)) {
                        fileWriter.write(log + "\n");
                        fileWriter.write(pass + "\n");
                        fileWriter.write(marks + "\n");
                    }
                }
                fileWriter.close();

                bufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream("./enter/buffer.txt")));
                fileWriter = new FileWriter("./enter/expert.txt");
                while ((log = bufferedReader.readLine()) != null) {
                    pass = bufferedReader.readLine();
                    marks = bufferedReader.readLine();

                    fileWriter.write(log + "\n");
                    fileWriter.write(pass + "\n");
                    fileWriter.write(marks + "\n");
                    fileWriter.flush();
                }
                fileWriter = new FileWriter("./enter/buffer.txt");
                fileWriter.write("");
                fileWriter.close();
            } else {
                aMessage = "Нет эксперта с таким логином!";
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return aMessage;
    }
    public static String changeExpert(String login, String password) {
        String aMessage = "";
        try {
            BufferedReader bufferedReader;
            FileWriter fileWriter;
            bufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream("./enter/expert.txt")));
            String log;
            String pass;
            String marks;
            while ((log = bufferedReader.readLine()) != null) {
                bufferedReader.readLine();
                bufferedReader.readLine();
                if (log.equals(login)) {
                    aMessage = "Информация об эксперте успешно отредактирована!";
                }
            }

            if (!aMessage.equals("")) {
                bufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream("./enter/expert.txt")));
                fileWriter = new FileWriter("./enter/buffer.txt", true);

                while ((log = bufferedReader.readLine()) != null) {
                    pass = bufferedReader.readLine();
                    marks = bufferedReader.readLine();

                    fileWriter.write(log + "\n");
                    if (!log.equals(login)) {
                        fileWriter.write(pass + "\n");
                    } else {
                        fileWriter.write(password + "\n");
                    }
                    fileWriter.write(marks + "\n");

                }
                fileWriter.close();

                bufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream("./enter/buffer.txt")));
                fileWriter = new FileWriter("./enter/expert.txt");
                while ((log = bufferedReader.readLine()) != null) {
                    pass = bufferedReader.readLine();
                    marks = bufferedReader.readLine();

                    fileWriter.write(log + "\n");
                    fileWriter.write(pass + "\n");
                    fileWriter.write(marks + "\n");
                    fileWriter.flush();
                }
                fileWriter = new FileWriter("./enter/buffer.txt");
                fileWriter.write("");
                fileWriter.close();
            } else {
                aMessage = "Нет эксперта с таким логином!";
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return aMessage;
    }
    public static String expertsNumber() {
        Integer number = 0;
        String buf;
        try {
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream("./enter/expert.txt")));
            while ((buf = bufferedReader.readLine()) != null) {
                number++;
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println(number);
        number /= 3;
        System.out.println(number);
        return number.toString();
    }

}
